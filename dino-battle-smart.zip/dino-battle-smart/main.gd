extends Control
# Dino Battle Smart - game pertarungan dino turn-based (Godot 4.x)
# Musuh punya AI "pintar": memprediksi kebiasaan pemain + lookahead 2 giliran.

const W := 1280.0
const H := 720.0

const DINOS := [
	{"name": "Rexi", "frames": ["res://assets/dino1_0.png", "res://assets/dino1_1.png", "res://assets/dino1_2.png"],
	 "attack": "res://assets/dino1_3.png", "faces_right": false, "pixel": false,
	 "hp": 125, "atk": 18, "def": 8, "spd": 9},
	{"name": "Crimson", "frames": ["res://assets/dino2_0.png"],
	 "attack": "res://assets/dino2_0.png", "faces_right": true, "pixel": true,
	 "hp": 100, "atk": 22, "def": 6, "spd": 13},
	{"name": "Greeny", "frames": ["res://assets/dino3_0.png", "res://assets/dino3_1.png", "res://assets/dino3_2.png"],
	 "attack": "res://assets/dino3_3.png", "faces_right": true, "pixel": true,
	 "hp": 112, "atk": 20, "def": 7, "spd": 10},
]

const ARENAS := ["res://assets/bg1.png", "res://assets/bg2.png", "res://assets/bg3.png"]
const ARENA_NAMES := ["Lembah Dino", "Hutan Rawa", "Arena Kuil"]
const DIFF_NAMES := ["Mudah (acak)", "Normal", "Pintar (adaptif)"]

const MOVES := [
	{"name": "Gigit", "desc": "Serangan biasa, akurat", "cost": 0, "power": 1.0, "acc": 0.95, "type": "atk"},
	{"name": "Terkam", "desc": "Sangat kuat, 70% akurat", "cost": 30, "power": 1.9, "acc": 0.70, "type": "atk"},
	{"name": "Bertahan", "desc": "Kurangi damage 60%, +10 energi", "cost": 0, "power": 0.0, "acc": 1.0, "type": "guard"},
	{"name": "Pulihkan", "desc": "Pulihkan 25% HP", "cost": 40, "power": 0.0, "acc": 1.0, "type": "heal"},
]
const ENERGY_REGEN := 15.0
const ENERGY_MAX := 100.0
const GUARD_BONUS := 10.0
const GUARD_MULT := 0.4
const HEAL_FRAC := 0.25

var sel_dino := 0
var sel_arena := 0
var difficulty := 2

var in_battle := false
var busy := false
var over := false
var anim_t := 0.0

var p: Dictionary = {}
var e: Dictionary = {}
var player_counts: Array = [1.0, 1.0, 1.0, 1.0]
var log_lines: Array = []
var log_label: Label
var move_buttons: Array = []
var menu_btn: Button

# ------------------------------------------------------------------ util UI
func _ready() -> void:
	randomize()
	show_menu()

func clear_screen() -> void:
	in_battle = false
	p = {}
	e = {}
	move_buttons = []
	for c in get_children():
		c.queue_free()

func make_label(txt: String, pos: Vector2, sz: Vector2, fsize: int, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = txt
	l.position = pos
	l.size = sz
	l.horizontal_alignment = align
	l.add_theme_font_size_override("font_size", fsize)
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func make_button(txt: String, pos: Vector2, sz: Vector2, fsize: int) -> Button:
	var b := Button.new()
	b.text = txt
	b.position = pos
	b.size = sz
	b.add_theme_font_size_override("font_size", fsize)
	return b

func style_bar(bar: ProgressBar, col: Color) -> void:
	var sb := StyleBoxFlat.new()
	sb.bg_color = col
	bar.add_theme_stylebox_override("fill", sb)
	var bgs := StyleBoxFlat.new()
	bgs.bg_color = Color(0.08, 0.08, 0.08, 0.85)
	bar.add_theme_stylebox_override("background", bgs)

func make_picture(path: String, pos: Vector2, sz: Vector2, pixel: bool, keep_aspect: bool) -> TextureRect:
	var tr := TextureRect.new()
	tr.texture = load(path)
	tr.position = pos
	tr.size = sz
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED if keep_aspect else TextureRect.STRETCH_SCALE
	tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if pixel else CanvasItem.TEXTURE_FILTER_LINEAR
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return tr

# --------------------------------------------------------------------- menu
var dino_cards: Array = []
var arena_cards: Array = []

func show_menu() -> void:
	clear_screen()
	dino_cards = []
	arena_cards = []
	var bg := make_picture(ARENAS[1], Vector2.ZERO, Vector2(W, H), true, false)
	add_child(bg)
	var shade := ColorRect.new()
	shade.color = Color(0, 0.05, 0.02, 0.6)
	shade.size = Vector2(W, H)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)

	add_child(make_label("DINO BATTLE SMART", Vector2(0, 14), Vector2(W, 70), 56, HORIZONTAL_ALIGNMENT_CENTER))
	add_child(make_label("Pilih Dinomu", Vector2(90, 92), Vector2(400, 32), 24))

	var xs := [90.0, 470.0, 850.0]
	for i in DINOS.size():
		var d: Dictionary = DINOS[i]
		var card := Button.new()
		card.position = Vector2(xs[i], 128)
		card.size = Vector2(340, 285)
		card.pressed.connect(_on_pick_dino.bind(i))
		add_child(card)
		card.add_child(make_picture(d.frames[0], Vector2(20, 10), Vector2(300, 170), d.pixel, true))
		card.add_child(make_label(d.name, Vector2(0, 185), Vector2(340, 32), 26, HORIZONTAL_ALIGNMENT_CENTER))
		card.add_child(make_label("HP %d   ATK %d   DEF %d   SPD %d" % [d.hp, d.atk, d.def, d.spd],
			Vector2(0, 228), Vector2(340, 28), 18, HORIZONTAL_ALIGNMENT_CENTER))
		dino_cards.append(card)

	add_child(make_label("Pilih Arena", Vector2(90, 424), Vector2(400, 32), 24))
	for i in ARENAS.size():
		var card := Button.new()
		card.position = Vector2(xs[i], 458)
		card.size = Vector2(340, 118)
		card.pressed.connect(_on_pick_arena.bind(i))
		add_child(card)
		card.add_child(make_picture(ARENAS[i], Vector2(6, 6), Vector2(328, 106), true, false))
		card.add_child(make_label(ARENA_NAMES[i], Vector2(0, 76), Vector2(340, 32), 22, HORIZONTAL_ALIGNMENT_CENTER))
		arena_cards.append(card)

	add_child(make_label("Tingkat AI:", Vector2(90, 618), Vector2(160, 40), 22))
	var ob := OptionButton.new()
	for n in DIFF_NAMES:
		ob.add_item(n)
	ob.select(difficulty)
	ob.position = Vector2(250, 614)
	ob.size = Vector2(260, 48)
	ob.add_theme_font_size_override("font_size", 20)
	ob.item_selected.connect(_on_pick_diff)
	add_child(ob)

	var start := make_button("MULAI BERTARUNG!", Vector2(790, 600), Vector2(400, 80), 30)
	start.pressed.connect(start_battle)
	add_child(start)
	refresh_menu()

func _on_pick_dino(i: int) -> void:
	sel_dino = i
	refresh_menu()

func _on_pick_arena(i: int) -> void:
	sel_arena = i
	refresh_menu()

func _on_pick_diff(i: int) -> void:
	difficulty = i

func refresh_menu() -> void:
	for i in dino_cards.size():
		dino_cards[i].modulate = Color.WHITE if i == sel_dino else Color(0.55, 0.55, 0.55)
	for i in arena_cards.size():
		arena_cards[i].modulate = Color.WHITE if i == sel_arena else Color(0.55, 0.55, 0.55)

# ------------------------------------------------------------------- battle
func make_fighter(di: int, is_player: bool) -> Dictionary:
	var d: Dictionary = DINOS[di]
	var frames: Array = []
	for pth in d.frames:
		frames.append(load(pth))
	var tex_h: float = frames[0].get_height()
	var sc: float = 230.0 / tex_h
	var holder := Node2D.new()
	var sprite := Sprite2D.new()
	sprite.texture = frames[0]
	sprite.scale = Vector2(sc, sc)
	sprite.position = Vector2(0, -tex_h * sc / 2.0)
	sprite.flip_h = (d.faces_right != is_player)
	sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST if d.pixel else CanvasItem.TEXTURE_FILTER_LINEAR
	holder.add_child(sprite)
	var bx: float = 300.0 if is_player else 980.0
	holder.position = Vector2(bx, 500)
	add_child(holder)
	return {
		"name": d.name, "hp": float(d.hp), "max": float(d.hp), "energy": 50.0,
		"atk": float(d.atk), "def": float(d.def), "spd": float(d.spd), "guard": false,
		"holder": holder, "sprite": sprite, "frames": frames, "atk_tex": load(d.attack),
		"pose": false, "is_player": is_player, "base_x": bx, "base_y": 500.0,
		"sprite_y": sprite.position.y,
	}

func make_hud(f: Dictionary, pos: Vector2) -> void:
	var panel := Panel.new()
	panel.position = pos
	panel.size = Vector2(430, 104)
	add_child(panel)
	var tag := "KAMU" if f.is_player else "MUSUH"
	panel.add_child(make_label("%s: %s" % [tag, f.name], Vector2(12, 4), Vector2(400, 30), 22))
	var hb := ProgressBar.new()
	hb.position = Vector2(12, 40)
	hb.size = Vector2(290, 20)
	hb.show_percentage = false
	hb.max_value = f.max
	hb.value = f.hp
	style_bar(hb, Color(0.2, 0.8, 0.25))
	panel.add_child(hb)
	var hl := make_label("", Vector2(310, 36), Vector2(115, 26), 18)
	panel.add_child(hl)
	var eb := ProgressBar.new()
	eb.position = Vector2(12, 70)
	eb.size = Vector2(290, 16)
	eb.show_percentage = false
	eb.max_value = ENERGY_MAX
	eb.value = f.energy
	style_bar(eb, Color(0.25, 0.55, 1.0))
	panel.add_child(eb)
	var el := make_label("", Vector2(310, 64), Vector2(115, 26), 18)
	panel.add_child(el)
	f["hp_bar"] = hb
	f["hp_lbl"] = hl
	f["en_bar"] = eb
	f["en_lbl"] = el
	update_hud(f, false)

func update_hud(f: Dictionary, animate: bool = true) -> void:
	f.hp_lbl.text = "HP %d/%d" % [int(f.hp), int(f.max)]
	f.en_lbl.text = "EN %d" % int(f.energy)
	if animate:
		var t := create_tween().set_parallel(true)
		t.tween_property(f.hp_bar, "value", f.hp, 0.35)
		t.tween_property(f.en_bar, "value", f.energy, 0.35)
	else:
		f.hp_bar.value = f.hp
		f.en_bar.value = f.energy

func start_battle() -> void:
	clear_screen()
	over = false
	busy = false
	player_counts = [1.0, 1.0, 1.0, 1.0]
	log_lines = []
	add_child(make_picture(ARENAS[sel_arena], Vector2.ZERO, Vector2(W, H), true, false))

	var ids := [0, 1, 2]
	ids.erase(sel_dino)
	var enemy_idx: int = ids.pick_random()
	p = make_fighter(sel_dino, true)
	e = make_fighter(enemy_idx, false)
	make_hud(p, Vector2(20, 14))
	make_hud(e, Vector2(830, 14))

	var panel := ColorRect.new()
	panel.color = Color(0, 0, 0, 0.65)
	panel.position = Vector2(0, 555)
	panel.size = Vector2(W, 165)
	add_child(panel)

	log_label = make_label("", Vector2(20, 562), Vector2(600, 150), 18)
	log_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(log_label)

	move_buttons = []
	for i in MOVES.size():
		var m: Dictionary = MOVES[i]
		var cost_txt := "" if m.cost == 0 else "  [E%d]" % m.cost
		var b := make_button("%d. %s%s\n%s" % [i + 1, m.name, cost_txt, m.desc],
			Vector2(650 + (i % 2) * 310, 566 + (i / 2) * 70), Vector2(300, 62), 16)
		b.pressed.connect(player_choose.bind(i))
		add_child(b)
		move_buttons.append(b)

	menu_btn = make_button("Menu", Vector2(W / 2 - 50, 14), Vector2(100, 40), 18)
	menu_btn.pressed.connect(show_menu)
	add_child(menu_btn)

	in_battle = true
	add_log("Pertarungan dimulai! %s melawan %s." % [p.name, e.name])
	add_log("Tingkat AI: %s" % DIFF_NAMES[difficulty])
	refresh_buttons()

func add_log(txt: String) -> void:
	log_lines.append(txt)
	while log_lines.size() > 6:
		log_lines.pop_front()
	log_label.text = "\n".join(log_lines)

func refresh_buttons() -> void:
	for i in move_buttons.size():
		move_buttons[i].disabled = busy or over or p.energy < MOVES[i].cost
	if menu_btn:
		menu_btn.disabled = busy and not over

func _process(delta: float) -> void:
	if not in_battle or p.is_empty() or e.is_empty():
		return
	anim_t += delta
	for f in [p, e]:
		var phase: float = 0.0 if f.is_player else 1.5
		f.sprite.position.y = f.sprite_y + sin(anim_t * 3.0 + phase) * 4.0
		if f.hp > 0 and not f.pose:
			f.sprite.texture = f.frames[int(anim_t * 4.0) % f.frames.size()]

func _unhandled_input(event: InputEvent) -> void:
	if in_battle and event is InputEventKey and event.pressed and not event.echo:
		var idx: int = event.keycode - KEY_1
		if idx >= 0 and idx < MOVES.size():
			player_choose(idx)

# --------------------------------------------------------------- turn logic
func player_choose(pm: int) -> void:
	if busy or over or not in_battle:
		return
	if p.energy < MOVES[pm].cost:
		return
	busy = true
	refresh_buttons()
	var em: int = ai_choose()
	# catat kebiasaan pemain (riwayat terbaru lebih berbobot)
	for i in player_counts.size():
		player_counts[i] *= 0.92
	player_counts[pm] += 1.0

	p.energy -= MOVES[pm].cost
	e.energy -= MOVES[em].cost
	p.guard = MOVES[pm].type == "guard"
	e.guard = MOVES[em].type == "guard"

	var p_first: bool = p.spd > e.spd or (p.spd == e.spd and randf() < 0.5)
	var seq: Array = [[p, e, pm], [e, p, em]] if p_first else [[e, p, em], [p, e, pm]]
	for s in seq:
		if p.hp <= 0 or e.hp <= 0:
			break
		await do_action(s[0], s[1], s[2])
		await get_tree().create_timer(0.25).timeout

	if p.hp <= 0 or e.hp <= 0:
		end_game()
		return
	p.energy = minf(ENERGY_MAX, p.energy + ENERGY_REGEN)
	e.energy = minf(ENERGY_MAX, e.energy + ENERGY_REGEN)
	p.guard = false
	e.guard = false
	update_hud(p)
	update_hud(e)
	busy = false
	refresh_buttons()

func calc_damage(att: Dictionary, tgt: Dictionary, mv: Dictionary, crit: bool) -> float:
	var dmg: float = att.atk * mv.power * randf_range(0.9, 1.1) - tgt.def * 0.5
	if crit:
		dmg *= 1.5
	if tgt.guard:
		dmg *= GUARD_MULT
	return maxf(1.0, round(dmg))

func do_action(att: Dictionary, tgt: Dictionary, mi: int) -> void:
	var mv: Dictionary = MOVES[mi]
	if mv.type == "atk":
		add_log("%s memakai %s!" % [att.name, mv.name])
		await lunge(att)
		if randf() > mv.acc:
			add_log("   ...tapi meleset!")
			float_text("Meleset!", tgt.holder.position + Vector2(0, -250), Color.WHITE)
		else:
			var crit: bool = randf() < 0.1
			var dmg: float = calc_damage(att, tgt, mv, crit)
			tgt.hp = maxf(0.0, tgt.hp - dmg)
			var note := ""
			if crit:
				note += " KRITIS!"
			if tgt.guard:
				note += " (ditahan)"
			add_log("   %s kena %d damage.%s" % [tgt.name, int(dmg), note])
			float_text("-%d" % int(dmg), tgt.holder.position + Vector2(0, -250), Color(1, 0.35, 0.3) if not crit else Color(1, 0.85, 0.2))
			update_hud(tgt)
			await hit_fx(tgt)
			if tgt.hp <= 0:
				add_log("   %s tumbang!" % tgt.name)
				await ko_fx(tgt)
		await lunge_back(att)
	elif mv.type == "guard":
		att.energy = minf(ENERGY_MAX, att.energy + GUARD_BONUS)
		add_log("%s bersiap bertahan." % att.name)
		float_text("Bertahan", att.holder.position + Vector2(0, -250), Color(0.5, 0.8, 1.0))
		var t := create_tween()
		t.tween_property(att.sprite, "modulate", Color(0.5, 0.7, 1.0), 0.15)
		t.tween_property(att.sprite, "modulate", Color.WHITE, 0.3)
		await t.finished
		update_hud(att)
	elif mv.type == "heal":
		var amt: float = minf(att.max - att.hp, round(att.max * HEAL_FRAC))
		att.hp += amt
		add_log("%s memulihkan %d HP." % [att.name, int(amt)])
		float_text("+%d" % int(amt), att.holder.position + Vector2(0, -250), Color(0.4, 1.0, 0.5))
		var t2 := create_tween()
		t2.tween_property(att.sprite, "modulate", Color(0.5, 1.0, 0.5), 0.15)
		t2.tween_property(att.sprite, "modulate", Color.WHITE, 0.3)
		await t2.finished
		update_hud(att)

# ---------------------------------------------------------------- animasi
func lunge(f: Dictionary) -> void:
	var dir: float = 1.0 if f.is_player else -1.0
	f.pose = true
	f.sprite.texture = f.atk_tex
	var t := create_tween()
	t.tween_property(f.holder, "position:x", f.base_x + dir * 150.0, 0.16).set_trans(Tween.TRANS_QUAD)
	await t.finished

func lunge_back(f: Dictionary) -> void:
	var t := create_tween()
	t.tween_property(f.holder, "position:x", f.base_x, 0.2)
	await t.finished
	f.pose = false

func hit_fx(f: Dictionary) -> void:
	var t := create_tween()
	t.tween_property(f.sprite, "modulate", Color(1, 0.3, 0.3), 0.06)
	t.tween_property(f.holder, "position:y", f.base_y - 10.0, 0.05)
	t.tween_property(f.holder, "position:y", f.base_y + 6.0, 0.05)
	t.tween_property(f.holder, "position:y", f.base_y, 0.05)
	t.tween_property(f.sprite, "modulate", Color.WHITE, 0.1)
	await t.finished

func ko_fx(f: Dictionary) -> void:
	var dir: float = -1.0 if f.is_player else 1.0
	var t := create_tween().set_parallel(true)
	t.tween_property(f.holder, "rotation_degrees", 80.0 * -dir, 0.5)
	t.tween_property(f.holder, "position:y", f.base_y + 40.0, 0.5)
	t.tween_property(f.sprite, "modulate", Color(0.6, 0.6, 0.6, 0.7), 0.5)
	await t.finished

func float_text(txt: String, pos: Vector2, col: Color) -> void:
	var l := make_label(txt, pos - Vector2(80, 0), Vector2(160, 40), 32, HORIZONTAL_ALIGNMENT_CENTER)
	l.add_theme_color_override("font_color", col)
	add_child(l)
	var t := create_tween().set_parallel(true)
	t.tween_property(l, "position:y", l.position.y - 70.0, 0.9)
	t.tween_property(l, "modulate:a", 0.0, 0.9)
	t.chain().tween_callback(l.queue_free)

func end_game() -> void:
	over = true
	busy = false
	refresh_buttons()
	var won: bool = e.hp <= 0
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.6)
	shade.size = Vector2(W, H)
	add_child(shade)
	var msg := "KAMU MENANG!" if won else "KAMU KALAH..."
	var l := make_label(msg, Vector2(0, 200), Vector2(W, 100), 80, HORIZONTAL_ALIGNMENT_CENTER)
	l.add_theme_color_override("font_color", Color(1, 0.9, 0.3) if won else Color(1, 0.4, 0.4))
	add_child(l)
	var again := make_button("Main Lagi", Vector2(W / 2 - 220, 360), Vector2(200, 70), 26)
	again.pressed.connect(start_battle)
	add_child(again)
	var back := make_button("Menu", Vector2(W / 2 + 20, 360), Vector2(200, 70), 26)
	back.pressed.connect(show_menu)
	add_child(back)

# ------------------------------------------------------------------ AI pintar
func exp_damage(att: Dictionary, tgt: Dictionary, mv: Dictionary, guarded: bool) -> float:
	var dmg: float = att.atk * mv.power - tgt.def * 0.5
	dmg = maxf(1.0, dmg) * 1.05
	if guarded:
		dmg *= GUARD_MULT
	return maxf(1.0, dmg) * mv.acc

# Simulasi satu giliran (nilai ekspektasi) dari sudut pandang s melawan o.
func expected_turn(s: Dictionary, o: Dictionary, sm: int, om: int) -> Array:
	var a: Dictionary = s.duplicate()
	var b: Dictionary = o.duplicate()
	a.energy -= MOVES[sm].cost
	b.energy -= MOVES[om].cost
	var a_guard: bool = MOVES[sm].type == "guard"
	var b_guard: bool = MOVES[om].type == "guard"
	var seq: Array = [[0, sm], [1, om]] if a.spd >= b.spd else [[1, om], [0, sm]]
	for st in seq:
		if a.hp <= 0 or b.hp <= 0:
			break
		var att: Dictionary = a if st[0] == 0 else b
		var tgt: Dictionary = b if st[0] == 0 else a
		var tgt_guard: bool = b_guard if st[0] == 0 else a_guard
		var mv: Dictionary = MOVES[st[1]]
		if mv.type == "atk":
			tgt.hp -= exp_damage(att, tgt, mv, tgt_guard)
		elif mv.type == "heal":
			att.hp = minf(att.max, att.hp + att.max * HEAL_FRAC)
		else:
			att.energy = minf(ENERGY_MAX, att.energy + GUARD_BONUS)
	a.energy = minf(ENERGY_MAX, a.energy + ENERGY_REGEN)
	b.energy = minf(ENERGY_MAX, b.energy + ENERGY_REGEN)
	return [a, b]

func state_value(a: Dictionary, b: Dictionary) -> float:
	if b.hp <= 0:
		return 1000.0
	if a.hp <= 0:
		return -1000.0
	return (a.hp / a.max - b.hp / b.max) * 100.0 + (a.energy - b.energy) * 0.15

func affordable(st: Dictionary) -> Array:
	var r: Array = []
	for i in MOVES.size():
		if st.energy >= MOVES[i].cost:
			r.append(i)
	return r

# Nilai terbaik giliran berikutnya (lawan dianggap memilih acak)
func best_next_value(s: Dictionary, o: Dictionary) -> float:
	var best: float = -INF
	var omoves: Array = affordable(o)
	for a in affordable(s):
		var sc: float = 0.0
		for m in omoves:
			var res: Array = expected_turn(s, o, a, m)
			sc += state_value(res[0], res[1])
		sc /= float(omoves.size())
		best = maxf(best, sc)
	return best

func ai_choose() -> int:
	var opts: Array = affordable(e)
	if difficulty == 0:
		return opts.pick_random()

	# Prediksi gerakan pemain: Normal = seragam, Pintar = berdasar kebiasaan pemain
	var pmoves: Array = affordable(p)
	var weights: Array = []
	var total: float = 0.0
	for m in pmoves:
		var w: float = player_counts[m] if difficulty == 2 else 1.0
		weights.append(w)
		total += w

	var best: int = opts[0]
	var best_score: float = -INF
	for a in opts:
		var score: float = 0.0
		for k in pmoves.size():
			var res: Array = expected_turn(e, p, a, pmoves[k])
			var v: float = state_value(res[0], res[1])
			if difficulty == 2 and v > -500.0 and v < 500.0:
				v = 0.6 * v + 0.4 * best_next_value(res[0], res[1])
			score += weights[k] / total * v
		score += randf() * (3.0 if difficulty == 2 else 12.0)
		if score > best_score:
			best_score = score
			best = a
	return best
