# Dino Battle Smart (Godot 4.x)

Cara menjalankan:
1. Buka Godot 4.3+ (4.2 ke atas juga bisa) -> Import -> pilih `project.godot`.
2. Tunggu import aset selesai, lalu tekan F5.

Cara bermain:
- Pilih dino, arena, dan tingkat AI di menu, lalu "MULAI BERTARUNG!".
- Klik tombol jurus atau tekan tombol 1-4.
- Energi (E) bertambah 15 tiap giliran. Terkam butuh 30, Pulihkan butuh 40.
- AI "Pintar" mempelajari kebiasaan jurusmu dan menghitung 2 giliran ke depan.

Aset ada di folder `assets/` (hasil olahan dari gambar yang kamu kirim).
